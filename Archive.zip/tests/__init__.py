"""
Test utilities and diagnostic tools for the ESCGNN project.
"""

