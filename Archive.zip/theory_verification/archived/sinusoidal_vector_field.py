import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import Normalize
import matplotlib.cm as cm

def generate_sinusoidal_vector_field(n_points=1000, pattern_amplitude=0.5, base_magnitude=1.0, max_extension=2.0):
    """
    Generate a vector field where vectors start at origin and extend to points 
    on/beyond a unit sphere based on proximity to a sinusoidal pattern.
    
    Parameters:
    -----------
    n_points : int
        Number of vectors to generate
    pattern_amplitude : float
        Amplitude of the sinusoidal pattern (0-1)
    base_magnitude : float
        Base magnitude (radius to unit sphere surface)
    max_extension : float
        Maximum extension beyond unit sphere
    
    Returns:
    --------
    vectors : np.ndarray
        Array of shape (n_points, 3) containing the vector endpoints
    magnitudes : np.ndarray
        Array of vector magnitudes
    pattern_values : np.ndarray
        Pattern values used for coloring
    """
    
    # Generate points uniformly distributed on unit sphere using spherical coordinates
    # Use the correct method for uniform distribution on sphere
    u = np.random.uniform(0, 1, n_points)
    v = np.random.uniform(0, 1, n_points)
    
    # Convert to spherical coordinates (phi: [0, 2π], theta: [0, π])
    phi = 2 * np.pi * u  # azimuthal angle
    theta = np.arccos(2 * v - 1)  # polar angle (uniform on sphere)
    
    # Convert spherical to Cartesian coordinates for unit sphere
    x_unit = np.sin(theta) * np.cos(phi)
    y_unit = np.sin(theta) * np.sin(phi)
    z_unit = np.cos(theta)
    
    # Define sinusoidal pattern on the sphere
    # Create a wave pattern using spherical harmonics-like function
    # Pattern based on both azimuthal and polar angles
    pattern_values = (
        0.5 + 0.3 * np.sin(3 * phi) * np.cos(2 * theta) +  # Primary wave
        0.2 * np.cos(2 * phi) * np.sin(theta)               # Secondary wave
    )
    
    # Normalize pattern values to [0, 1] range
    pattern_values = (pattern_values - pattern_values.min()) / (pattern_values.max() - pattern_values.min())
    
    # Calculate vector magnitudes based on pattern
    # Base magnitude gets us to unit sphere, pattern adds extension
    magnitudes = base_magnitude + pattern_amplitude * pattern_values * (max_extension - base_magnitude)
    
    # Create final vectors (from origin to scaled endpoints)
    vectors = np.column_stack([
        magnitudes * x_unit,
        magnitudes * y_unit,
        magnitudes * z_unit
    ])
    
    return vectors, magnitudes, pattern_values

def plot_vector_field_on_sphere(vectors, magnitudes, pattern_values, title="Sinusoidal Vector Field"):
    """
    Plot the vector field with vectors colored by their L2-norm.
    
    Parameters:
    -----------
    vectors : np.ndarray
        Vector endpoints
    magnitudes : np.ndarray
        Vector magnitudes (L2-norms)
    pattern_values : np.ndarray
        Pattern values for additional reference
    title : str
        Plot title
    """
    
    # Normalize magnitudes to [0, 1] for coloring
    norm_magnitudes = (magnitudes - magnitudes.min()) / (magnitudes.max() - magnitudes.min())
    
    # Create 3D plot
    fig = plt.figure(figsize=(15, 5))
    
    # Plot 1: Vectors colored by L2-norm
    ax1 = fig.add_subplot(131, projection='3d')
    
    # Plot unit sphere for reference (wireframe)
    u_sphere = np.linspace(0, 2 * np.pi, 20)
    v_sphere = np.linspace(0, np.pi, 20)
    x_sphere = np.outer(np.cos(u_sphere), np.sin(v_sphere))
    y_sphere = np.outer(np.sin(u_sphere), np.sin(v_sphere))
    z_sphere = np.outer(np.ones(np.size(u_sphere)), np.cos(v_sphere))
    ax1.plot_wireframe(x_sphere, y_sphere, z_sphere, alpha=0.2, color='gray')
    
    # Plot vectors as points colored by L2-norm
    scatter1 = ax1.scatter(vectors[:, 0], vectors[:, 1], vectors[:, 2], 
                          c=norm_magnitudes, cmap='viridis', s=20, alpha=0.7)
    
    # Plot some actual vectors (sample for clarity)
    sample_idx = np.random.choice(len(vectors), size=min(100, len(vectors)//10), replace=False)
    for idx in sample_idx:
        ax1.plot([0, vectors[idx, 0]], [0, vectors[idx, 1]], [0, vectors[idx, 2]], 
                'k-', alpha=0.3, linewidth=0.5)
    
    ax1.set_xlabel('X')
    ax1.set_ylabel('Y')
    ax1.set_zlabel('Z')
    ax1.set_title(f'{title}\n(Colored by L2-norm)')
    plt.colorbar(scatter1, ax=ax1, shrink=0.5, aspect=5, label='Normalized L2-norm')
    
    # Plot 2: Vectors colored by pattern values
    ax2 = fig.add_subplot(132, projection='3d')
    ax2.plot_wireframe(x_sphere, y_sphere, z_sphere, alpha=0.2, color='gray')
    
    scatter2 = ax2.scatter(vectors[:, 0], vectors[:, 1], vectors[:, 2], 
                          c=pattern_values, cmap='plasma', s=20, alpha=0.7)
    
    ax2.set_xlabel('X')
    ax2.set_ylabel('Y')
    ax2.set_zlabel('Z')
    ax2.set_title(f'{title}\n(Colored by Pattern Value)')
    plt.colorbar(scatter2, ax=ax2, shrink=0.5, aspect=5, label='Pattern Value')
    
    # Plot 3: Magnitude distribution
    ax3 = fig.add_subplot(133)
    ax3.hist(magnitudes, bins=30, alpha=0.7, color='skyblue', edgecolor='black')
    ax3.set_xlabel('Vector Magnitude')
    ax3.set_ylabel('Frequency')
    ax3.set_title('Distribution of Vector Magnitudes')
    ax3.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()
    
    # Print statistics
    print(f"Vector Statistics:")
    print(f"  Number of vectors: {len(vectors)}")
    print(f"  Magnitude range: [{magnitudes.min():.3f}, {magnitudes.max():.3f}]")
    print(f"  Mean magnitude: {magnitudes.mean():.3f}")
    print(f"  Pattern value range: [{pattern_values.min():.3f}, {pattern_values.max():.3f}]")
    print(f"  Vectors extending beyond unit sphere: {np.sum(magnitudes > 1.0)} ({100*np.sum(magnitudes > 1.0)/len(magnitudes):.1f}%)")

def create_hemisphere_focused_field(n_points=1000, hemisphere='upper', pattern_type='sine_wave'):
    """
    Create a vector field focused on one hemisphere with enhanced sinusoidal patterns.
    
    Parameters:
    -----------
    n_points : int
        Number of vectors to generate
    hemisphere : str
        'upper', 'lower', or 'both'
    pattern_type : str
        'sine_wave', 'spiral', or 'bands'
    """
    
    # Generate points with hemisphere bias
    if hemisphere == 'upper':
        # Bias towards upper hemisphere (z > 0)
        u = np.random.uniform(0, 1, n_points)
        v = np.random.uniform(0.5, 1, n_points)  # Bias towards upper hemisphere
    elif hemisphere == 'lower':
        # Bias towards lower hemisphere (z < 0)
        u = np.random.uniform(0, 1, n_points)
        v = np.random.uniform(0, 0.5, n_points)  # Bias towards lower hemisphere
    else:
        # Both hemispheres
        u = np.random.uniform(0, 1, n_points)
        v = np.random.uniform(0, 1, n_points)
    
    phi = 2 * np.pi * u
    theta = np.arccos(2 * v - 1)
    
    # Convert to Cartesian
    x_unit = np.sin(theta) * np.cos(phi)
    y_unit = np.sin(theta) * np.sin(phi)
    z_unit = np.cos(theta)
    
    # Define different pattern types
    if pattern_type == 'sine_wave':
        # Classic sine wave pattern
        pattern_values = 0.5 + 0.5 * np.sin(4 * phi) * np.cos(3 * theta)
    elif pattern_type == 'spiral':
        # Spiral pattern
        pattern_values = 0.5 + 0.5 * np.sin(phi + 3 * theta)
    elif pattern_type == 'bands':
        # Latitudinal bands
        pattern_values = 0.5 + 0.5 * np.cos(5 * theta)
    else:
        # Default complex pattern
        pattern_values = (
            0.5 + 0.3 * np.sin(3 * phi) * np.cos(2 * theta) +
            0.2 * np.cos(2 * phi) * np.sin(theta)
        )
    
    # Normalize pattern
    pattern_values = (pattern_values - pattern_values.min()) / (pattern_values.max() - pattern_values.min())
    
    # Calculate magnitudes (base = 1.0, extends up to 2.5 based on pattern)
    base_magnitude = 1.0
    max_extension = 2.5
    magnitudes = base_magnitude + 0.8 * pattern_values * (max_extension - base_magnitude)
    
    # Create vectors
    vectors = np.column_stack([
        magnitudes * x_unit,
        magnitudes * y_unit,
        magnitudes * z_unit
    ])
    
    return vectors, magnitudes, pattern_values

# Example usage and demonstration
if __name__ == "__main__":
    print("Generating sinusoidal vector fields on unit sphere...\n")
    
    # Example 1: Basic sinusoidal pattern
    print("1. Basic sinusoidal pattern:")
    vectors1, mags1, patterns1 = generate_sinusoidal_vector_field(
        n_points=1500, 
        pattern_amplitude=0.7, 
        base_magnitude=1.0, 
        max_extension=2.0
    )
    plot_vector_field_on_sphere(vectors1, mags1, patterns1, "Basic Sinusoidal Pattern")
    
    # Example 2: Upper hemisphere with sine wave
    print("\n2. Upper hemisphere with enhanced sine wave:")
    vectors2, mags2, patterns2 = create_hemisphere_focused_field(
        n_points=1500, 
        hemisphere='upper', 
        pattern_type='sine_wave'
    )
    plot_vector_field_on_sphere(vectors2, mags2, patterns2, "Upper Hemisphere Sine Wave")
    
    # Example 3: Spiral pattern
    print("\n3. Spiral pattern:")
    vectors3, mags3, patterns3 = create_hemisphere_focused_field(
        n_points=1500, 
        hemisphere='both', 
        pattern_type='spiral'
    )
    plot_vector_field_on_sphere(vectors3, mags3, patterns3, "Spiral Pattern")
    
    # Example 4: Demonstrate the key features
    print("\n4. Analysis of vector field properties:")
    vectors, magnitudes, pattern_values = generate_sinusoidal_vector_field(n_points=2000)
    
    # Show that all vectors start at origin
    origins = np.zeros_like(vectors)
    print(f"All vectors start at origin: {np.allclose(origins, 0)}")
    
    # Show L2-norms (magnitudes) vary with pattern
    l2_norms = np.linalg.norm(vectors, axis=1)
    correlation = np.corrcoef(l2_norms, pattern_values)[0, 1]
    print(f"Correlation between L2-norm and pattern value: {correlation:.3f}")
    
    # Show range of extensions beyond unit sphere
    beyond_sphere = l2_norms > 1.0
    print(f"Vectors extending beyond unit sphere: {np.sum(beyond_sphere)} / {len(vectors)}")
    print(f"Max extension: {l2_norms.max():.3f} (beyond unit sphere by {l2_norms.max() - 1.0:.3f})") 