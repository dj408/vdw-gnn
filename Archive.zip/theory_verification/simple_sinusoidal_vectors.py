import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import torch
from sklearn.neighbors import NearestNeighbors
from torch_geometric.data import Data
from torch_geometric.utils import to_torch_coo_tensor
import sys
import os
from typing import Tuple, List, Dict, Optional, Union, Any, Literal

# Add the parent directory to sys.path to import from data_processing
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from data_processing.process_pyg_data import process_pyg_data


def normalize_vector_norms_for_coloring(
    vectors: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Calculate L2 norms of vectors and normalize them to [0,1] for coloring.
    
    Args:
        vectors: np.ndarray, shape (n_points, 3) - Vector endpoints
    
    Returns:
        Tuple of (l2_norms, normalized_norms):
        - l2_norms: np.ndarray, shape (n_points,) - L2 norms of the vectors
        - normalized_norms: np.ndarray, shape (n_points,) - L2 norms normalized to [0,1] for coloring
    """
    l2_norms = np.linalg.norm(vectors, axis=1)
    normalized_norms = (l2_norms - l2_norms.min()) / (l2_norms.max() - l2_norms.min())
    return l2_norms, normalized_norms


def generate_sinusoidal_sphere_vectors(
    n_points: int = 1000, 
    base_magnitude: float = 1.0,
    max_magnitude: float = 2.0,
    x_axis_increase_rate: float = 0.5,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate vectors that:
    1. Start at the origin (0,0,0)
    2. Extend at least to the unit sphere surface
    3. Have increased magnitude based on proximity to a sinusoidal pattern
    4. Have additional magnitude increase along the x-axis
    5. Are colored by their L2-norm normalized to [0,1]
    
    Args:
        n_points: Number of vectors to generate
        base_magnitude: Base magnitude of the vectors (default: 1.0)
        max_magnitude: Maximum magnitude of the vectors
        x_axis_increase_rate: Rate at which vector magnitude increases along x-axis
            (0.0 = no increase, 1.0 = significant increase)
    
    Returns:
        Tuple of (vectors, l2_norms, normalized_norms):
        - vectors: np.ndarray, shape (n_points, 3) - Vector endpoints (since they start at origin)
        - l2_norms: np.ndarray, shape (n_points,) - L2 norms of the vectors
        - normalized_norms: np.ndarray, shape (n_points,) - L2 norms normalized to [0,1] for coloring
    """
    
    # Step 1: Generate uniformly distributed points on unit sphere
    # Use correct spherical coordinate sampling for uniform distribution
    u = np.random.uniform(0, 1, n_points)
    v = np.random.uniform(0, 1, n_points)
    
    # Convert to spherical coordinates
    phi = 2 * np.pi * u  # azimuthal angle [0, 2π]
    theta = np.arccos(2 * v - 1)  # polar angle [0, π] 
    
    # Convert to Cartesian coordinates on unit sphere
    x_unit = np.sin(theta) * np.cos(phi)
    y_unit = np.sin(theta) * np.sin(phi)
    z_unit = np.cos(theta)
    
    # Step 2: Define sinusoidal pattern on the sphere
    # Create an interesting wave pattern using spherical coordinates
    pattern = np.sin(4 * phi) * np.cos(3 * theta)  # Wave pattern
    
    # Step 3: Calculate vector magnitudes based on pattern proximity and x-axis position
    # Base magnitude of 1.0 ensures vectors reach at least unit sphere surface
    
    # Normalize pattern to [0,1] and use it to scale magnitude
    pattern_normalized = (pattern - pattern.min()) / (pattern.max() - pattern.min())
    pattern_component = pattern_normalized * (max_magnitude - base_magnitude) * 0.7  # 70% weight for pattern
    
    # Add x-axis dependent component
    # Normalize x-coordinates from [-1,1] to [0,1]
    x_normalized = (x_unit + 1.0) / max_magnitude
    x_axis_component = x_axis_increase_rate * x_normalized * (max_magnitude - base_magnitude) * (1.0 / max_magnitude)
    
    # Combine all components
    magnitudes = base_magnitude + pattern_component + x_axis_component
    
    # Step 4: Create final vectors (from origin to scaled points)
    vectors = np.column_stack([
        magnitudes * x_unit,
        magnitudes * y_unit,
        magnitudes * z_unit
    ])
    
    # Step 5: Calculate L2 norms and normalize to [0,1] for coloring
    l2_norms, normalized_norms = normalize_vector_norms_for_coloring(vectors)
    
    return vectors, l2_norms, normalized_norms


def rotate_vectors(
    vectors: np.ndarray, 
    rotation_angles: Tuple[float, float, float], 
) -> np.ndarray:
    """
    Rotate vectors by specified angles around x, y, and z axes in sequence.
    
    Args:
        vectors: np.ndarray, shape (n_points, 3) - Vector endpoints to rotate
        rotation_angles: Tuple of (x_angle, y_angle, z_angle) in degrees
    
    Returns:
        rotated_vectors: np.ndarray, shape (n_points, 3) - Rotated vector endpoints
    """
    
    # Start with original vectors
    rotated_vectors = vectors.copy()
    
    # Apply rotations in sequence (x -> y -> z)
    for axis, angle in zip(['x', 'y', 'z'], rotation_angles):
        if angle == 0:
            continue
            
        # Convert angle to radians
        angle_rad = np.radians(angle)
        cos_a = np.cos(angle_rad)
        sin_a = np.sin(angle_rad)
        
        # Define rotation matrix for current axis
        if axis == 'x':
            rotation_matrix = np.array([
                [1, 0, 0],
                [0, cos_a, -sin_a],
                [0, sin_a, cos_a]
            ])
        elif axis == 'y':
            rotation_matrix = np.array([
                [cos_a, 0, sin_a],
                [0, 1, 0],
                [-sin_a, 0, cos_a]
            ])
        else:  # z-axis
            rotation_matrix = np.array([
                [cos_a, -sin_a, 0],
                [sin_a, cos_a, 0],
                [0, 0, 1]
            ])
        
        # Apply rotation
        rotated_vectors = np.dot(rotated_vectors, rotation_matrix.T)
    
    return rotated_vectors


def construct_knn_graph(
    vectors: np.ndarray, 
    k: int = 10, 
    weighted: bool = False
) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    """
    Construct a k-nearest neighbors graph from vector endpoints.
    
    Args:
        vectors: np.ndarray, shape (n_points, 3) - Vector endpoints
        k: Number of nearest neighbors
        weighted: Whether to use edge weights (inverse distances) or unweighted graph
    
    Returns:
        Tuple of (edge_index, edge_weight):
        - edge_index: torch.Tensor, shape (2, num_edges) - Edge connectivity in PyTorch Geometric format
        - edge_weight: torch.Tensor, shape (num_edges,) or None - Edge weights (inverse distances) if weighted=True, None otherwise
    """
    
    # Use scikit-learn's NearestNeighbors for efficient k-nn search
    nbrs = NearestNeighbors(n_neighbors=k+1, algorithm='auto').fit(vectors)
    distances, indices = nbrs.kneighbors(vectors)
    
    # Remove self-loops (first neighbor is always the point itself)
    distances = distances[:, 1:]
    indices = indices[:, 1:]
    
    # Create edge list
    num_nodes = len(vectors)
    edge_list = []
    weights = [] if weighted else None
    
    for i in range(num_nodes):
        for j in range(k):
            neighbor = indices[i, j]
            # Add edge from i to neighbor
            edge_list.append([i, neighbor])
            if weighted:
                dist = distances[i, j]
                # Use inverse distance as weight (with small epsilon to avoid division by zero)
                weights.append(1.0 / (dist + 1e-8))
    
    # Convert to torch tensors
    edge_index = torch.tensor(edge_list).T.long()
    edge_weight = torch.tensor(weights).float() if weighted else None
    
    # Make the graph symmetric (add reverse edges)
    reverse_edges = torch.stack([edge_index[1], edge_index[0]], dim=0)
    edge_index = torch.cat([edge_index, reverse_edges], dim=1)
    if weighted:
        edge_weight = torch.cat([edge_weight, edge_weight], dim=0)
    
    return edge_index, edge_weight


def compute_Q_matrix(
    vectors: np.ndarray, 
    edge_index: torch.Tensor, 
    edge_weight: torch.Tensor, 
    # vector_dim: int = 3, 
    verbosity: int = 0
) -> torch.sparse.FloatTensor:
    """
    Compute the Q diffusion operator matrix using the official process_pyg_data function.
    This ensures we use the exact same ESCGNN methodology as the main codebase.
    
    Args:
        vectors: np.ndarray, shape (n_points, 3) - Vector endpoints
        edge_index: torch.Tensor, shape (2, num_edges) - Edge connectivity
        edge_weight: torch.Tensor, shape (num_edges,) - Edge weights
        vector_dim: Dimension of vectors (default: 3) - unused but kept for API compatibility
        verbosity: Verbosity level (0 = no output, 1+ = increasing output)
    
    Returns:
        Q: torch.sparse.FloatTensor - Sparse Q matrix for vector diffusion
    """
    
    n_points = len(vectors)
    
    # Create PyTorch Geometric Data object
    data_dict = {
        'v': torch.tensor(vectors).float(),
        'edge_index': edge_index,
        'num_nodes': n_points
    }
    if edge_weight is not None:
        data_dict['edge_weight'] = edge_weight
    
    data = Data(**data_dict)
    
    # Use the official process_pyg_data function
    if verbosity >= 1:
        print("    Using official process_pyg_data implementation...")
    processed_data = process_pyg_data(
        data,
        geom_feat_key='v',
        device='cpu',
        return_data_object=True
    )
    
    # Extract Q matrix
    Q = processed_data.Q
    
    # Debug: Check Q matrix properties
    if verbosity >= 1:
        Q_values = Q.coalesce().values()
        print(f"    Q matrix stats: min={Q_values.min():.4f}, max={Q_values.max():.4f}, mean={Q_values.mean():.4f}")
        print(f"    Q matrix size: {Q.size()}, nnz: {Q._nnz()}")
        
        # Check P matrix properties too
        P = processed_data.P
        P_values = P.values()
        print(f"    P matrix stats: min={P_values.min():.4f}, max={P_values.max():.4f}, mean={P_values.mean():.4f}")
        P_dense = P.to_dense()
        row_sums = P_dense.sum(dim=1)
        print(f"    P row sums: min={row_sums.min():.4f}, max={row_sums.max():.4f} (should be ~1.0)")
    
    return Q


def compute_vector_diffusions(
    vectors: np.ndarray, 
    Q: torch.sparse.FloatTensor, 
    steps: List[int] = [1, 2, 4, 8], 
    verbosity: int = 0,
    diffusion_mode: Literal['powers', 'wavelets'] = 'powers'
) -> Dict[int, np.ndarray]:
    """
    Compute diffusion steps: Q^step * v for each step, or wavelet differences.
    
    Args:
        vectors: np.ndarray, shape (n_points, 3) - Original vectors
        Q: torch.sparse.FloatTensor - Diffusion operator matrix
        steps: For 'powers' mode: powers of Q to compute.
              For 'wavelets' mode: list of t values for wavelet differences.
              For example, [0,1,2,4] computes (I-Q)x, (Q-Q^2)x, (Q^2-Q^4)x.
        verbosity: Verbosity level (0 = no output, 1+ = increasing output)
        diffusion_mode: 'powers' for Q^t v or 'wavelets' for wavelet differences
    
    Returns:
        diffused_vectors: Dictionary mapping step -> diffused vectors
    """
    
    # Reshape vectors to column vector format (n*d, 1)
    v_flat = torch.tensor(vectors).float().view(-1, 1)
    n_points = len(vectors)
    
    # Debug: check original vector magnitudes
    if verbosity >= 1:
        original_mags = np.linalg.norm(vectors, axis=1)
        print(f"    Original vector magnitudes: [{original_mags.min():.3f}, {original_mags.max():.3f}] (mean: {original_mags.mean():.3f})")
    
    diffused_vectors = {}
    
    if diffusion_mode == 'powers':
        # Standard diffusion mode - compute Q^t v for each step
        target_step = steps[-1]
        current_step = 1
        Qv = torch.sparse.mm(Q, v_flat)
        
        while current_step <= target_step:
            if current_step in steps:
                v_diffused = Qv.view(n_points, 3).detach().numpy()
                diffused_vectors[current_step] = v_diffused

                # Debug: check diffused vector magnitudes
                if verbosity >= 1:
                    diffused_mags = np.linalg.norm(v_diffused, axis=1)
                    print(f"    Q^{current_step}v magnitudes: [{diffused_mags.min():.3f}, {diffused_mags.max():.3f}] (mean: {diffused_mags.mean():.3f})")
                    print(f"    Q^{current_step}v magnitude std: {diffused_mags.std():.3f} (original std: {original_mags.std():.3f})")
            
            if current_step < target_step:
                Qv = torch.sparse.mm(Q, Qv)
            current_step += 1
            
    else:  # wavelets mode
        # Compute wavelet differences between consecutive steps
        # First compute all needed powers of Q
        max_power = max(steps)
        Q_powers = {0: v_flat}  # Q^0 = I
        current_power = 1
        current_Qv = v_flat
        
        while current_power <= max_power:
            current_Qv = torch.sparse.mm(Q, current_Qv)
            if current_power in steps:
                Q_powers[current_power] = current_Qv
            current_power += 1
        
        # Compute wavelet differences
        for i in range(len(steps) - 1):
            t1 = steps[i]
            t2 = steps[i + 1]
            v_diffused = (Q_powers[t1] - Q_powers[t2]).view(n_points, 3).detach().numpy()
            # Store with the step index as the key to match the visualization
            diffused_vectors[steps[i + 1]] = v_diffused
            
            # Debug: check diffused vector magnitudes
            if verbosity >= 1:
                diffused_mags = np.linalg.norm(v_diffused, axis=1)
                print(f"    W_{t1}-{t2}v magnitudes: [{diffused_mags.min():.3f}, {diffused_mags.max():.3f}] (mean: {diffused_mags.mean():.3f})")
                print(f"    W_{t1}-{t2}v magnitude std: {diffused_mags.std():.3f} (original std: {original_mags.std():.3f})")
    
    return diffused_vectors


def visualize_vector_field(
    vectors: np.ndarray, 
    l2_norms: np.ndarray,
    normalized_norms: np.ndarray,
    fig_size: Tuple[int, int] = (6, 4),
    title: str = "",
    cmap: str = 'viridis',
    include_colorbar: bool = False,
    include_origin: bool = False,
    include_unit_sphere: bool = False,
    endpoint_size: int = 25,
    show_labels: bool = True,
    print_stats: bool = False
) -> None:
    """
    Visualize the vector field with endpoints colored by normalized L2-norm.
    
    Args:
        vectors: np.ndarray - Vector endpoints
        l2_norms: np.ndarray - L2 norms of the vectors
        normalized_norms: np.ndarray - L2 norms normalized to [0,1] for coloring
        fig_size: Figure size tuple (width, height)
        title: Plot title string
        cmap: Colormap name for coloring
        include_colorbar: Whether to include colorbar
        include_origin: Whether to highlight the origin point
        include_unit_sphere: Whether to include a unit sphere for reference
        endpoint_size: Size of scatter plot points
        show_labels: Whether to show axis labels
        print_stats: Whether to print vector field statistics
    """
    fig = plt.figure(figsize=fig_size)
    
    # 3D scatter of vector endpoints colored by L2-norm
    ax1 = fig.add_subplot(111, projection='3d')
    
    if include_unit_sphere:
        # Draw unit sphere for reference
        u_sphere = np.linspace(0, 2 * np.pi, 30)
        v_sphere = np.linspace(0, np.pi, 20)
        x_sphere = np.outer(np.cos(u_sphere), np.sin(v_sphere))
        y_sphere = np.outer(np.sin(u_sphere), np.sin(v_sphere))
        z_sphere = np.outer(np.ones(np.size(u_sphere)), np.cos(v_sphere))
        ax1.plot_wireframe(x_sphere, y_sphere, z_sphere, alpha=0.2, color='lightgray')
    
    # Plot vector endpoints colored by normalized L2-norm
    scatter = ax1.scatter(vectors[:, 0], vectors[:, 1], vectors[:, 2], 
                         c=normalized_norms, cmap=cmap, s=endpoint_size, alpha=0.8)
    
    if include_origin:
        # Draw origin point
        ax1.scatter([0], [0], [0], color='red', s=100, marker='o', label='Origin')
    
    # Draw sample vectors from origin to endpoints
    # sample_indices = np.random.choice(len(vectors), size=50, replace=False)
    # for idx in sample_indices:
    #     ax1.plot([0, vectors[idx, 0]], [0, vectors[idx, 1]], [0, vectors[idx, 2]], 
    #             'k-', alpha=0.3, linewidth=0.8)
    
    if show_labels:
        ax1.set_xlabel('X')
        ax1.set_ylabel('Y')
        ax1.set_zlabel('Z')
    ax1.set_title(title)
    if include_origin:
        ax1.legend()
    
    if include_colorbar:
        # Add colorbar
        cbar = plt.colorbar(scatter, ax=ax1, shrink=0.6, aspect=20)
        cbar.set_label('Normalized L2-norm [0,1]')
    
    plt.tight_layout()
    plt.show()
    
    if print_stats:
        # Print summary statistics
        print(f"\nVector Field Statistics:")
        print(f"  Total vectors: {len(vectors)}")
        print(f"  L2-norm range: [{l2_norms.min():.3f}, {l2_norms.max():.3f}]")
        print(f"  Mean L2-norm: {l2_norms.mean():.3f}")
        print(f"  Vectors reaching unit sphere: {np.sum(l2_norms >= 1.0)}")
        print(f"  Vectors extending beyond unit sphere: {np.sum(l2_norms > 1.0)} ({100*np.sum(l2_norms > 1.0)/len(l2_norms):.1f}%)")
        print(f"  Maximum extension beyond sphere: {l2_norms.max() - 1.0:.3f}")
    
        # Analyze x-axis correlation
        x_coords = vectors[:, 0] / l2_norms  # Normalized x-coordinates of unit vectors
        x_correlation = np.corrcoef(x_coords, l2_norms)[0, 1]
        print(f"  Correlation between x-coordinate and magnitude: {x_correlation:.3f}")


def visualize_diffusion_grid(
    original_vectors: np.ndarray, 
    rotated_vectors_list: List[np.ndarray], 
    diffusion_results_list: List[Dict[int, np.ndarray]], 
    rotation_angles_list: List[Tuple[float, float, float]], 
    diffusion_mode: Literal['powers', 'wavelets'] = 'powers',
    diffusion_steps: List[int] = [1, 2, 4, 8],
    figsize: Tuple[int, int] = (16, 12), 
    cmap: str = 'viridis', 
    show_labels: bool = False, 
    include_unit_sphere: bool = False,
    endpoint_size: int = 25,
    reverse_angles: bool = False, 
    fixed_positions: bool = False, 
    operator_symbol: str = 'Q', 
    vector_symbol: str = 'x',
    verbosity: int = 0, 
    save_dir: Optional[str] = None,
    normalization: Literal['auto', 'original', 'per_column', 'global_powers', 'percentile_per_column'] = 'auto',
    percentiles: Tuple[float, float] = (1.0, 99.0),
) -> None:
    """
    Visualize original and rotated vector fields with their diffusion results in a grid.
    Normalization options control how colors are scaled for diffused columns:
      - 'auto': per-column normalization for powers; global range for wavelets (default)
      - 'original': all powers columns use the original field's range
      - 'per_column': each powers column uses its own range computed across all rows
      - 'global_powers': all powers columns share one global range across all rows/steps
      - 'percentile_per_column': like per_column but uses percentiles to clip outliers
    
    Args:
        original_vectors: np.ndarray - Original vector field
        rotated_vectors_list: List of rotated vector fields
        diffusion_results_list: List of diffusion results for each field
        rotation_angles_list: List of rotation angle tuples (x_angle, y_angle, z_angle) in degrees
        diffusion_mode: 'powers' for Q^t v or 'wavelets' for wavelet differences
        diffusion_steps: For 'powers' mode: powers of Q to compute.
                        For 'wavelets' mode: list of t values for wavelet differences.
                        For example, [0,1,2,4] computes (I-Q)x, (Q-Q^2)x, (Q^2-Q^4)x.
        figsize: Figure size tuple
        cmap: Colormap name
        show_labels: Whether to show axis and tick labels (default: False)
        include_unit_sphere: Whether to include a unit sphere for reference
        endpoint_size: Size of scatter plot points
        reverse_angles: Whether to take 360 - rotation angles
        fixed_positions: If True, keep vector endpoints at original spatial positions and only 
            change colors based on diffused magnitudes. If False, show diffused 
            vector positions and color by diffused magnitudes (default behavior).
        operator_symbol: Symbol to use for the diffusion operator matrix (default: 'Q')
        vector_symbol: Symbol to use for the vector feature matrix (default: 'x')
        verbosity: Verbosity level (0 = no output, 1+ = increasing output)
        save_dir: Directory to save the plot. If None, plot is displayed but not saved.
    """
    
    # Prepare all fields (original + rotated)
    all_fields = [original_vectors] + rotated_vectors_list
    all_rotations = [(0, 0, 0)] + list(rotation_angles_list)
    
    n_rows = len(all_fields)
    n_cols = 1 + len(diffusion_steps)  # Original field + diffusion steps
    
    # Calculate normalization range using original field's full range for column 0
    if verbosity >= 1:
        print("Computing normalization scale...")
    
    # Use original field's full range for color mapping of column 0
    original_norms = np.linalg.norm(original_vectors, axis=1)
    global_min = original_norms.min()
    global_max = original_norms.max()
    global_range = global_max - global_min
    original_mean = original_norms.mean()
    
    # For wavelet columns (1+), compute global min/max across all diffusion steps
    if diffusion_mode == 'wavelets':
        wavelet_norms = []
        for diffusion_results in diffusion_results_list:
            for step in diffusion_steps[1:]:  # Skip first step
                diffused_field = diffusion_results[step]
                diffused_norms = np.linalg.norm(diffused_field, axis=1)
                wavelet_norms.extend(diffused_norms)
        wavelet_norms = np.array(wavelet_norms)
        wavelet_min = wavelet_norms.min()
        wavelet_max = wavelet_norms.max()
        wavelet_range = wavelet_max - wavelet_min
        if verbosity >= 1:
            print(f"  Wavelet columns range: [{wavelet_min:.3f}, {wavelet_max:.3f}]")

    # Prepare normalization strategy for powers mode
    chosen_normalization = normalization
    if normalization == 'auto':
        chosen_normalization = 'per_column' if diffusion_mode == 'powers' else 'original'

    per_step_min_max: Dict[int, Tuple[float, float]] = {}
    powers_min = None
    powers_max = None
    if diffusion_mode == 'powers':
        if chosen_normalization in ('per_column', 'percentile_per_column'):
            for step in diffusion_steps[1:]:
                all_norms = np.concatenate([
                    np.linalg.norm(d[step], axis=1) for d in diffusion_results_list
                ])
                if chosen_normalization == 'percentile_per_column':
                    low, high = np.percentile(all_norms, [percentiles[0], percentiles[1]])
                else:
                    low, high = all_norms.min(), all_norms.max()
                per_step_min_max[step] = (float(low), float(high))
            if verbosity >= 1:
                print("  Using per-column ranges for powers mode" + (" with percentile clipping" if chosen_normalization == 'percentile_per_column' else "") + ".")
        elif chosen_normalization == 'global_powers':
            all_powers_norms = np.concatenate([
                np.linalg.norm(d[step], axis=1)
                for d in diffusion_results_list
                for step in diffusion_steps[1:]
            ])
            powers_min = float(all_powers_norms.min())
            powers_max = float(all_powers_norms.max())
            if verbosity >= 1:
                print(f"  Using global powers range: [{powers_min:.3f}, {powers_max:.3f}]")
    
    # Also check convergence behavior for diagnostics
    max_step = max(diffusion_steps)
    convergence_values = []
    for diffusion_results in diffusion_results_list:
        converged_field = diffusion_results[max_step]
        converged_norms = np.linalg.norm(converged_field, axis=1)
        convergence_values.extend(converged_norms)
    
    convergence_values = np.array(convergence_values)
    convergence_mean = convergence_values.mean()
    convergence_position = (convergence_mean - global_min) / global_range
    
    if verbosity >= 1:
        print(f"  Original field range: [{global_min:.3f}, {global_max:.3f}] (mean: {original_mean:.3f})")
        print(f"  Convergence value ({operator_symbol}^{max_step}v mean): {convergence_mean:.3f}")
        print(f"  Convergence position in colormap: {convergence_position:.2f} (0=purple, 0.5=green, 1=yellow)")
        if diffusion_mode == 'powers':
            if chosen_normalization == 'original':
                print("  Using original field range for powers columns.")
        else:
            print("  Using wavelet range for wavelet columns.")
    
    fig = plt.figure(figsize=figsize)
    
    # Store axes for later labeling
    row_axes = []  # Store leftmost axes for row labels
    col_axes = []
    
    for row, (field, rotation) in enumerate(zip(all_fields, all_rotations)):
        
        # Column 0: Original/rotated field
        ax = fig.add_subplot(n_rows, n_cols, row * n_cols + 1, projection='3d')
        
        # Store axes for labeling
        row_axes.append(ax)  # Store leftmost axis for row labels
        if row == 0:  # Store top row axes for column labels
            col_axes.append(ax)
        
        # Calculate L2 norms and normalize using original field's full range
        l2_norms = np.linalg.norm(field, axis=1)
        normalized_norms = (l2_norms - global_min) / global_range
        # Clamp to [0, 1] range for proper color mapping
        normalized_norms = np.clip(normalized_norms, 0, 1)
        
        # Draw unit sphere
        if include_unit_sphere:
            u_sphere = np.linspace(0, 2 * np.pi, 20)
            v_sphere = np.linspace(0, np.pi, 15)
            x_sphere = np.outer(np.cos(u_sphere), np.sin(v_sphere))
            y_sphere = np.outer(np.sin(u_sphere), np.sin(v_sphere))
            z_sphere = np.outer(np.ones(np.size(u_sphere)), np.cos(v_sphere))
            ax.plot_wireframe(x_sphere, y_sphere, z_sphere, alpha=0.15, color='lightgray')
        
        # Plot vector endpoints
        scatter = ax.scatter(field[:, 0], field[:, 1], field[:, 2], 
                           c=normalized_norms, cmap=cmap, s=endpoint_size, alpha=0.7,
                           vmin=0, vmax=1)
        
        # Conditionally show labels
        if show_labels:
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('Z')
        else:
            ax.set_xticks([])
            ax.set_yticks([])
            ax.set_zticks([])
        
        # Columns 1+: Diffusion steps
        for col, step in enumerate(diffusion_steps[1:]):  # Skip first step for wavelets
            ax = fig.add_subplot(n_rows, n_cols, row * n_cols + col + 2, projection='3d')
            
            # Store top row axes for column labels
            if row == 0:
                col_axes.append(ax)
            
            diffused_field = diffusion_results_list[row][step]
            diffused_l2_norms = np.linalg.norm(diffused_field, axis=1)
            
            # Normalize based on mode
            if diffusion_mode == 'powers':
                if chosen_normalization == 'original':
                    if col == 0 and verbosity >= 1:
                        print("Using original field range for powers columns")
                    diffused_normalized_norms = (diffused_l2_norms - global_min) / max(global_range, 1e-12)
                elif chosen_normalization == 'global_powers':
                    if col == 0 and verbosity >= 1:
                        print("Using global powers range across all powers columns")
                    col_min, col_max = powers_min, powers_max  # type: ignore
                    col_range = max((col_max - col_min), 1e-12)  # type: ignore
                    diffused_normalized_norms = (diffused_l2_norms - col_min) / col_range  # type: ignore
                else:  # per-column variants
                    if col == 0 and verbosity >= 1:
                        msg = "Using per-column ranges for powers columns"
                        if chosen_normalization == 'percentile_per_column':
                            msg += f" (percentiles {percentiles[0]}-{percentiles[1]})"
                        print(msg)
                    col_min, col_max = per_step_min_max[step]
                    col_range = max((col_max - col_min), 1e-12)
                    diffused_normalized_norms = (diffused_l2_norms - col_min) / col_range
            else:  # wavelets
                # Use global wavelet range for consistent color mapping across all wavelet columns
                if col == 0 and verbosity >= 1:
                    print("Using wavelet range for consistent color mapping across wavelet columns")
                diffused_normalized_norms = (diffused_l2_norms - wavelet_min) / max(wavelet_range, 1e-12)
            
            # Clamp to [0, 1] range for proper color mapping
            diffused_normalized_norms = np.clip(diffused_normalized_norms, 0, 1)
            
            # Draw unit sphere
            if include_unit_sphere:
                ax.plot_wireframe(x_sphere, y_sphere, z_sphere, alpha=0.15, color='lightgray')
            
            # Choose positions and colors based on mode
            if fixed_positions:
                # Use original spatial positions, but color by diffused magnitudes
                plot_positions = field
                plot_colors = diffused_normalized_norms
            else:
                # Use diffused positions and color by diffused magnitudes (default)
                plot_positions = diffused_field
                plot_colors = diffused_normalized_norms
            
            # Plot vector endpoints
            scatter = ax.scatter(plot_positions[:, 0], plot_positions[:, 1], plot_positions[:, 2], 
                               c=plot_colors, cmap=cmap, s=endpoint_size, alpha=0.7,
                               vmin=0, vmax=1)
            
            # Conditionally show labels
            if show_labels:
                ax.set_xlabel('X')
                ax.set_ylabel('Y')
                ax.set_zlabel('Z')
            else:
                ax.set_xticks([])
                ax.set_yticks([])
                ax.set_zticks([])
    
    # Add row labels (rotation angles) on the left using stored axes
    for row, (ax, rotation) in enumerate(zip(row_axes, all_rotations)):
        if rotation == (0, 0, 0):
            row_label = 'Original'
        else:
            # Create label showing only nonzero rotations
            rotation_parts = []
            for axis, angle in zip(['x', 'y', 'z'], rotation):
                if angle != 0:
                    if reverse_angles:
                        angle = 360 - angle
                    rotation_parts.append(f"{axis}={angle}°")
            row_label = ', '.join(rotation_parts)
        ax.text2D(-0.15, 0.5, row_label, transform=ax.transAxes, 
                 rotation=90, va='center', ha='center', fontsize=16)
    
    # Add column labels (diffusion steps) at the top using stored axes
    if diffusion_mode == 'powers':
        column_labels = [f'${vector_symbol}$'] + \
            [f'${operator_symbol}^{{{step}}}{vector_symbol}$' for step in diffusion_steps[1:]]
    else:  # wavelets
        column_labels = [
            f'${vector_symbol}$'] + \
            [f'($Q^{{{diffusion_steps[i]}}}-Q^{{{diffusion_steps[i+1]}}}){vector_symbol}$' for i in range(len(diffusion_steps)-1)]
    for ax, label in zip(col_axes, column_labels):
        ax.text2D(0.5, 1.1, label, transform=ax.transAxes, 
                 va='center', ha='center', fontsize=16)
    
    plt.tight_layout()
    
    # Save plot if save_dir is provided
    if save_dir is not None:
        import os
        os.makedirs(save_dir, exist_ok=True)
        
        # Generate filename based on parameters
        mode_suffix = "_fixed_pos" if fixed_positions else "_moving_pos"
        mode_suffix += "_wavelets" if diffusion_mode == 'wavelets' else "_powers"
        filename = f"diffusion_grid_{operator_symbol}_{vector_symbol}{mode_suffix}.png"
        filepath = os.path.join(save_dir, filename)
        
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        if verbosity >= 0:
            print(f"Plot saved to: {filepath}")
    
    plt.show()


def process_vector_field_with_diffusion(
    vectors: np.ndarray, 
    rotation_angles_list: List[Tuple[float, float, float]], 
    k: int = 10, 
    diffusion_steps: List[int] = [1, 2, 4, 8], 
    weighted: bool = False,
    verbosity: int = 0,
    diffusion_mode: Literal['powers', 'wavelets'] = 'powers'
) -> Dict[str, Any]:
    """
    Process a vector field: generate rotations, compute Q matrices, and apply diffusions.
    
    Args:
        vectors: np.ndarray - Original vector field
        rotation_angles_list: List of rotation angle tuples (x_angle, y_angle, z_angle) in degrees
        k: Number of nearest neighbors for k-nn graph
        diffusion_steps: For 'powers' mode: powers of Q to compute.
                        For 'wavelets' mode: list of t values for wavelet differences.
                        For example, [0,1,2,4] computes (I-Q)x, (Q-Q^2)x, (Q^2-Q^4)x.
        weighted: Whether to use edge weights (inverse distances) or unweighted graph
        verbosity: Verbosity level (0 = no output, 1+ = increasing output)
        diffusion_mode: 'powers' for Q^t v or 'wavelets' for wavelet differences
        
    Returns:
        results: Dictionary containing all results
    """
    
    results = {
        'original': {'vectors': vectors, 'rotation': (0, 0, 0)},
        'rotated': [],
        'diffusions': []
    }
    
    # Process original field
    if verbosity >= 1:
        print("Processing original field...")
    edge_index, edge_weight = construct_knn_graph(vectors, k=k, weighted=weighted)
    
    # Use full ESCGNN Q matrix with change-of-basis matrices
    if verbosity >= 1:
        print("  Computing full ESCGNN Q matrix...")
    Q_original = compute_Q_matrix(vectors, edge_index, edge_weight, verbosity=verbosity)
    
    diffusions_original = compute_vector_diffusions(vectors, Q_original, diffusion_steps, verbosity=verbosity, diffusion_mode=diffusion_mode)
    results['diffusions'].append(diffusions_original)
    
    # Process rotated fields
    for rotation_angles in rotation_angles_list:
        if verbosity >= 1:
            print(f"Processing rotation {rotation_angles}°...")
        rotated_vectors = rotate_vectors(vectors, rotation_angles)
        results['rotated'].append({'vectors': rotated_vectors, 'rotation': rotation_angles})
        
        # Compute diffusions for rotated field - MUST use its own Q matrix for equivariance!
        edge_index_rot, edge_weight_rot = construct_knn_graph(rotated_vectors, k=k, weighted=weighted)
        Q_rotated = compute_Q_matrix(rotated_vectors, edge_index_rot, edge_weight_rot, verbosity=verbosity)
        diffusions_rotated = compute_vector_diffusions(rotated_vectors, Q_rotated, diffusion_steps, verbosity=verbosity, diffusion_mode=diffusion_mode)
        results['diffusions'].append(diffusions_rotated)
    
    return results


# Example usage
if __name__ == "__main__":
    # Set verbosity level (0 = no output, 1+ = increasing output)
    verbosity = 1
    
    if verbosity >= 1:
        print("Generating sinusoidal vector field on unit sphere...")
    
    # Generate the vector field
    vectors, l2_norms, normalized_norms = generate_sinusoidal_sphere_vectors(n_points=500, x_axis_increase_rate=1.0)
    
    # Define rotation angles as tuples of (x_angle, y_angle, z_angle)
    rotation_angles_list = [
        (90, 0, 0),    # 90° around x-axis
        (0, 90, 0),    # 90° around y-axis
        (0, 0, 90),    # 90° around z-axis
        (45, 45, 0),   # Combined x and y rotations
        (45, 0, 45),   # Combined x and z rotations
        (0, 45, 45),   # Combined y and z rotations
        (45, 45, 45),  # Combined x, y, and z rotations
    ]
    
    # Process vector field with diffusions
    if verbosity >= 1:
        print("\nProcessing vector field with k-nn graphs and diffusions...")
    results = process_vector_field_with_diffusion(
        vectors, 
        rotation_angles_list, 
        k=20, 
        diffusion_steps=[1, 2, 4, 8], 
        weighted=True, 
        verbosity=verbosity
    )
    
    # Extract data for visualization
    original_vectors = results['original']['vectors']
    rotated_vectors_list = [r['vectors'] for r in results['rotated']]
    diffusion_results_list = results['diffusions']
    
    # Visualize everything in a grid - default mode (moving positions)
    if verbosity >= 1:
        print("\nVisualizing diffusion grid (moving positions)...")
    visualize_diffusion_grid(
        original_vectors, 
        rotated_vectors_list, 
        diffusion_results_list,
        rotation_angles_list,
        diffusion_steps=[1, 2, 4, 8],
        figsize=(20, 16),
        cmap='viridis',
        show_labels=False,
        include_unit_sphere=True,
        reverse_angles=True,
        fixed_positions=False,
        operator_symbol='Q',
        vector_symbol='x',
        verbosity=verbosity
    )
    
    # Visualize everything in a grid - fixed positions mode
    if verbosity >= 1:
        print("\nVisualizing diffusion grid (fixed positions, color shows magnitude evolution)...")
    visualize_diffusion_grid(
        original_vectors, 
        rotated_vectors_list, 
        diffusion_results_list,
        rotation_angles_list,
        diffusion_steps=[1, 2, 4, 8],
        figsize=(20, 16),
        cmap='viridis',
        show_labels=False,
        include_unit_sphere=True,
        reverse_angles=True,
        fixed_positions=True,
        operator_symbol='Q',
        vector_symbol='x',
        verbosity=verbosity
    )
    
    # Verify key properties
    if verbosity >= 1:
        print("\nVerification:")
        print(f"All vectors start at origin: {np.allclose(np.zeros((len(vectors), 3)), 0)}")
        print(f"Original min magnitude: {l2_norms.min():.3f} (should be ≥ 1.0)")
        print(f"Number of rotation configurations processed: {len(rotation_angles_list)}")
        print(f"Diffusion steps computed: {[1, 2, 4, 8]}")
        print(f"Grid visualization: {len(results['diffusions'])} rows × 5 columns") 